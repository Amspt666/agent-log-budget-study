# Supplementary Material S1: numerical evidence and audit

Manuscript: Failure Localization in Agent Trajectories under Limited Log Budgets: An Empirical Study
Author: Hongming Guo
Prepared: 2026-09-15. No new model calls were made for these analyses.

Full upstream Who&When commit: `f4d2b6da464a826580e59b3a0eae15ea2d642d7c` (abbreviated in the manuscript for readability).

## Files

- `scored_rows.csv`: 9,450 final logical evaluations, identified by job key and upstream trajectory path. No question text, logs, model response text, or credentials are included.
- `cells.csv`: 21 model-condition cells with group-weighted outcomes. Each contains 450 records, 150 trajectories and 112 groups.
- `audit.json`: all eighteen full-minus-bounded comparisons; raw sign-flip p-values, within-configuration Holm adjustment (`holm6`), and global Holm adjustment (`holm18`); input/configuration audit and recorded-usage accounting.
- `configuration_sensitivity.json`: the eight Kimi full/repeat-0 jobs whose requested output cap was 4096 instead of 8192, and six paired tests after removing their five entire groups from all Kimi conditions (107 groups, 140 trajectories).
- `bounded_comparisons.json`: eighteen post hoc same-budget strategy comparisons; Holm adjustment across this separate family. The signed difference is left minus right, not full minus bounded.
- `*_rows.tex`: generated table bodies for traceability. The submission manuscript already contains these rows inline.

## Column definitions

`correct` is exact failure-step matching against the benchmark annotation; `abstain` is a null prediction; `wrong` is a non-null incorrect prediction. They sum to one per row. `within1` allows an index difference of at most one. `visible` means the annotated step was selected, not that sufficient contextual evidence was available. `empty` marks an empty selected array. `chars` counts serialized Unicode code points of that array only. `censored_correct` sets correctness to zero for every job represented in the failed archive, regardless of its recovered answer. It is not measured first-attempt accuracy.

Group weighting: first average repetitions within trajectory, then trajectories within group, then groups equally. No pooled cross-provider aggregate is used as a model-ranking metric.

## Interpretation and scope

All 18 main point differences are positive, but five pass within-configuration correction and only one passes the global 18-test correction. None of the same-budget strategy comparisons passes its separate 18-test adjustment. The cap-excluded Kimi subset retains positive point differences but none passes its six-test correction.

The final manifest does not perfectly describe all historical requests: eight cap deviations are explicitly retained and disclosed. Assertions validating stored predictions against annotations do not validate the annotations themselves. The original response archive is not included, so these files support numerical reproduction from scored outcomes, not independent inspection of all generated responses.

The generation scripts need the private local response archive to rebuild the full audit. The separate `reproduce_scored_evidence.py` in this package reproduces numerical comparisons from the supplied scored rows without API access. Post hoc checks were added after observing the main results and are not externally preregistered.

## Cost

The recorded-usage estimate is CNY 84.78923522 under the saved price assumptions, including eleven usage-bearing archived failures. Kimi price assumptions are approximate. The estimate is not an invoice and is not an upper bound. Missing usage in 102 archived files is not evidence of zero billing.
